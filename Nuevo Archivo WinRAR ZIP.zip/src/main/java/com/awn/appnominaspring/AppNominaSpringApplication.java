package com.awn.appnominaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppNominaSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(AppNominaSpringApplication.class, args);
    }

}
